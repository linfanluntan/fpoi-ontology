# FPOI V7.5 PROTEAS post-diagnostic clean rerun

Corrected gate-set provenance (authoritative config = gates_v4_postdiagnostic_clean.json):
not-yet-committed; post-diagnostic corrected gate set

Corrected gate SHA-256:
2ae7ecaf8611da2cfb546f5ac4410f95234b542009aa01220f0b7fc9dfc8be18

Manifest SHA-256:
6b3deb6cc770055e631ca81ecb941b70695516f23e0e9bdcd7ce08c520e7ac60

G5 source:
required prior QA artifact: /content/drive/MyDrive/FPOI_DATA/PROTEAS/lesion_correspondence_QA.csv; sha256=68b9408bceb7100e3f7bc26473269db30fb6eefb9bd06d669902b1e8a40847bf

Clinical source:
/content/drive/MyDrive/FPOI_DATA/PROTEAS/PROTEAS_clinical_readable.csv

Interpretation:
- G0–G4 are archive/course-level gates inherited by follow-up observations.
- G5 is observation-level.
- `gate_evidence.csv` uses `baseline_*` names for inherited baseline metrics.
- Report archive-level status as the independent unit, with follow-up counts as nested observations.
- This gate set was corrected after diagnostic inspection and is not claimed to be prespecified.
